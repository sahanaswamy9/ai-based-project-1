import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calculator, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import cropBackground from "@/assets/crop-background.jpg";

interface FertilityCheckProps {
  isAuthenticated: boolean;
}

// Fertility standards based on agricultural research
const OPTIMAL_RANGES = {
  nitrogen: { min: 40, max: 60, unit: "mg/kg" },
  phosphorus: { min: 15, max: 25, unit: "mg/kg" },
  potassium: { min: 150, max: 250, unit: "mg/kg" },
  ph_level: { min: 6.0, max: 7.5, unit: "pH" },
  organic_matter: { min: 3, max: 5, unit: "%" },
  calcium: { min: 1000, max: 2000, unit: "mg/kg" },
  magnesium: { min: 100, max: 200, unit: "mg/kg" },
  sulfur: { min: 10, max: 20, unit: "mg/kg" },
  zinc: { min: 1, max: 3, unit: "mg/kg" },
  iron: { min: 4, max: 10, unit: "mg/kg" },
  moisture_content: { min: 15, max: 25, unit: "%" },
  electrical_conductivity: { min: 0.5, max: 2, unit: "dS/m" },
};

const FertilityCheck = ({ isAuthenticated }: FertilityCheckProps) => {
  const [formData, setFormData] = useState({
    nitrogen: "",
    phosphorus: "",
    potassium: "",
    ph_level: "",
    organic_matter: "",
    calcium: "",
    magnesium: "",
    sulfur: "",
    zinc: "",
    iron: "",
    moisture_content: "",
    electrical_conductivity: "",
  });

  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const calculateFertility = async () => {
    // Validate all fields are filled
    const emptyFields = Object.values(formData).filter((v) => !v);
    if (emptyFields.length > 0) {
      toast.error("Please fill in all fields");
      return;
    }

    setAnalyzing(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Calculate fertility score
      let totalScore = 0;
      let maxScore = 0;
      const recommendations: string[] = [];

      Object.entries(formData).forEach(([key, value]) => {
        const numValue = parseFloat(value);
        const optimal = OPTIMAL_RANGES[key as keyof typeof OPTIMAL_RANGES];

        if (optimal) {
          maxScore += 100;
          if (numValue >= optimal.min && numValue <= optimal.max) {
            totalScore += 100;
          } else if (numValue < optimal.min) {
            const deficit = ((optimal.min - numValue) / optimal.min) * 100;
            totalScore += Math.max(0, 100 - deficit);
            recommendations.push(
              `Increase ${key.replace("_", " ")} (currently ${numValue} ${optimal.unit}, optimal: ${optimal.min}-${optimal.max} ${optimal.unit})`
            );
          } else {
            const excess = ((numValue - optimal.max) / optimal.max) * 100;
            totalScore += Math.max(0, 100 - excess);
            recommendations.push(
              `Reduce ${key.replace("_", " ")} (currently ${numValue} ${optimal.unit}, optimal: ${optimal.min}-${optimal.max} ${optimal.unit})`
            );
          }
        }
      });

      const fertilityPercentage = (totalScore / maxScore) * 100;
      let fertilityLevel = "Low";
      if (fertilityPercentage >= 75) fertilityLevel = "High";
      else if (fertilityPercentage >= 50) fertilityLevel = "Medium";

      const analysisResult = {
        fertilityPercentage: fertilityPercentage.toFixed(1),
        fertilityLevel,
        recommendations: recommendations.slice(0, 5), // Top 5 recommendations
      };

      setResult(analysisResult);

      // Save to database
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from("soil_analyses").insert({
          user_id: user.id,
          analysis_type: "fertility",
          nitrogen: parseFloat(formData.nitrogen),
          phosphorus: parseFloat(formData.phosphorus),
          potassium: parseFloat(formData.potassium),
          ph_level: parseFloat(formData.ph_level),
          organic_matter: parseFloat(formData.organic_matter),
          calcium: parseFloat(formData.calcium),
          magnesium: parseFloat(formData.magnesium),
          sulfur: parseFloat(formData.sulfur),
          zinc: parseFloat(formData.zinc),
          iron: parseFloat(formData.iron),
          moisture_content: parseFloat(formData.moisture_content),
          electrical_conductivity: parseFloat(formData.electrical_conductivity),
          fertility_percentage: parseFloat(analysisResult.fertilityPercentage),
          fertility_level: analysisResult.fertilityLevel,
          mineral_recommendations: analysisResult.recommendations,
        });
      }

      toast.success("Fertility analysis complete!");
    } catch (error) {
      toast.error("Analysis failed. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center"
      style={{ backgroundImage: `url(${cropBackground})` }}
    >
      <div className="min-h-screen bg-background/95">
        <Navigation isAuthenticated={isAuthenticated} />

        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold text-center mb-8">Soil Fertility Analysis</h1>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Input Form */}
            <Card>
              <CardHeader>
                <CardTitle>Enter Soil Parameters</CardTitle>
                <CardDescription>
                  Provide laboratory test results for comprehensive analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(OPTIMAL_RANGES).map(([key, { unit }]) => (
                    <div key={key} className="space-y-2">
                      <Label htmlFor={key} className="capitalize">
                        {key.replace("_", " ")} ({unit})
                      </Label>
                      <Input
                        id={key}
                        type="number"
                        step="0.1"
                        value={formData[key as keyof typeof formData]}
                        onChange={(e) => handleInputChange(key, e.target.value)}
                        placeholder="0.0"
                      />
                    </div>
                  ))}
                </div>

                <Button
                  onClick={calculateFertility}
                  disabled={analyzing}
                  className="w-full mt-4"
                >
                  {analyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Calculator className="w-4 h-4 mr-2" />
                      Calculate Fertility
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Results Section */}
            <Card>
              <CardHeader>
                <CardTitle>Fertility Results</CardTitle>
                <CardDescription>
                  Detailed analysis and recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                {result ? (
                  <div className="space-y-4">
                    <div className={`p-6 rounded-lg text-center ${
                      result.fertilityLevel === "High"
                        ? "bg-primary/20"
                        : result.fertilityLevel === "Medium"
                        ? "bg-accent/20"
                        : "bg-destructive/20"
                    }`}>
                      <p className="text-sm text-muted-foreground mb-2">Fertility Score</p>
                      <p className="text-5xl font-bold mb-2">{result.fertilityPercentage}%</p>
                      <p className={`text-xl font-bold ${
                        result.fertilityLevel === "High"
                          ? "text-primary"
                          : result.fertilityLevel === "Medium"
                          ? "text-accent"
                          : "text-destructive"
                      }`}>
                        {result.fertilityLevel}
                      </p>
                    </div>

                    <div>
                      <h3 className="font-bold mb-3">Recommendations</h3>
                      <div className="space-y-2">
                        {result.recommendations.length > 0 ? (
                          result.recommendations.map((rec: string, index: number) => (
                            <div
                              key={index}
                              className="bg-muted p-3 rounded-lg text-sm"
                            >
                              {rec}
                            </div>
                          ))
                        ) : (
                          <p className="text-muted-foreground">
                            All parameters are within optimal range!
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                    <Calculator className="w-16 h-16 mb-4 opacity-50" />
                    <p>Enter soil parameters to calculate fertility</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FertilityCheck;
