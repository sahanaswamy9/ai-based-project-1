import { Navigation } from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Target, Users, Award } from "lucide-react";
import cropBackground from "@/assets/crop-background.jpg";

interface AboutProps {
  isAuthenticated: boolean;
}

const About = ({ isAuthenticated }: AboutProps) => {
  return (
    <div
      className="min-h-screen bg-cover bg-center"
      style={{ backgroundImage: `url(${cropBackground})` }}
    >
      <div className="min-h-screen bg-background/95">
        <Navigation isAuthenticated={isAuthenticated} />

        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-center mb-8">About Our Platform</h1>

            <Card className="p-8 mb-8">
              <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
              <p className="text-muted-foreground mb-4">
                We're dedicated to revolutionizing agriculture through advanced soil analysis
                technology. Our platform combines artificial intelligence with agricultural science
                to provide farmers and researchers with accurate, actionable insights about soil
                health and fertility.
              </p>
              <p className="text-muted-foreground">
                By making professional-grade soil analysis accessible to everyone, we aim to
                improve crop yields, promote sustainable farming practices, and contribute to
                global food security.
              </p>
            </Card>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-bold mb-2">Precision</h3>
                <p className="text-sm text-muted-foreground">
                  Advanced algorithms for accurate soil type detection and fertility analysis
                </p>
              </Card>

              <Card className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Users className="w-8 h-8 text-secondary" />
                </div>
                <h3 className="font-bold mb-2">Accessibility</h3>
                <p className="text-sm text-muted-foreground">
                  User-friendly interface designed for farmers of all technical backgrounds
                </p>
              </Card>

              <Card className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                  <Award className="w-8 h-8 text-accent" />
                </div>
                <h3 className="font-bold mb-2">Sustainability</h3>
                <p className="text-sm text-muted-foreground">
                  Promoting environmentally responsible farming through data-driven decisions
                </p>
              </Card>
            </div>

            <Card className="p-8">
              <h2 className="text-2xl font-bold mb-4">Our Technology</h2>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>
                    <strong>AI-Powered Image Recognition:</strong> Advanced machine learning
                    models trained on thousands of soil samples for accurate type classification
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>
                    <strong>Comprehensive Fertility Analysis:</strong> Multi-parameter testing
                    based on established agricultural research standards
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>
                    <strong>Personalized Recommendations:</strong> Tailored advice for crop
                    selection and soil amendments based on your specific results
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>
                    <strong>Historical Tracking:</strong> Store and compare results over time to
                    monitor soil health improvements
                  </span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
