import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Upload, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import cropBackground from "@/assets/crop-background.jpg";

interface SoilDetectionProps {
  isAuthenticated: boolean;
}

// Soil type classification data
const SOIL_DATABASE = {
  sandy: {
    crops: ["Carrots", "Potatoes", "Radishes", "Lettuce", "Watermelon"],
    characteristics: "Well-drained, low nutrient retention",
  },
  clay: {
    crops: ["Rice", "Wheat", "Cabbage", "Broccoli", "Brussels sprouts"],
    characteristics: "Poor drainage, high nutrient retention",
  },
  loam: {
    crops: ["Tomatoes", "Corn", "Beans", "Most vegetables", "Fruits"],
    characteristics: "Ideal balance of drainage and nutrients",
  },
  silt: {
    crops: ["Grass", "Shrubs", "Pasture", "Some vegetables"],
    characteristics: "Moderate drainage, good fertility",
  },
  "sandy-loam": {
    crops: ["Root vegetables", "Strawberries", "Peppers", "Cucumbers"],
    characteristics: "Good drainage with decent nutrient retention",
  },
};

const SoilDetection = ({ isAuthenticated }: SoilDetectionProps) => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        toast.error("Please select a valid image file");
        return;
      }
      setSelectedImage(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResult(null);
    }
  };

  const analyzeSoil = async () => {
    if (!selectedImage) {
      toast.error("Please select an image first");
      return;
    }

    setAnalyzing(true);

    try {
      // Simulate AI analysis
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Random soil type selection for demo
      const soilTypes = Object.keys(SOIL_DATABASE);
      const randomSoilType = soilTypes[Math.floor(Math.random() * soilTypes.length)];
      const soilData = SOIL_DATABASE[randomSoilType as keyof typeof SOIL_DATABASE];

      const analysisResult = {
        soilType: randomSoilType,
        confidence: (85 + Math.random() * 10).toFixed(1),
        recommendedCrops: soilData.crops,
        characteristics: soilData.characteristics,
      };

      setResult(analysisResult);

      // Save to database
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from("soil_analyses").insert({
          user_id: user.id,
          analysis_type: "detection",
          soil_type: analysisResult.soilType,
          recommended_crops: analysisResult.recommendedCrops,
          detection_confidence: parseFloat(analysisResult.confidence),
        });
      }

      toast.success("Soil analysis complete!");
    } catch (error) {
      toast.error("Analysis failed. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center"
      style={{ backgroundImage: `url(${cropBackground})` }}
    >
      <div className="min-h-screen bg-background/95">
        <Navigation isAuthenticated={isAuthenticated} />

        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold text-center mb-8">Soil Type Detection</h1>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Upload Section */}
            <Card>
              <CardHeader>
                <CardTitle>Upload Soil Image</CardTitle>
                <CardDescription>
                  Select a clear image of the soil sample for analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="image">Soil Image</Label>
                  <Input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="cursor-pointer"
                  />
                </div>

                {previewUrl && (
                  <div className="border-2 border-dashed border-border rounded-lg p-4">
                    <img
                      src={previewUrl}
                      alt="Soil preview"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                  </div>
                )}

                <Button
                  onClick={analyzeSoil}
                  disabled={!selectedImage || analyzing}
                  className="w-full"
                >
                  {analyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Analyze Soil
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Results Section */}
            <Card>
              <CardHeader>
                <CardTitle>Analysis Results</CardTitle>
                <CardDescription>
                  Detected soil type and crop recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                {result ? (
                  <div className="space-y-4">
                    <div className="bg-fertile-light p-4 rounded-lg">
                      <h3 className="font-bold text-lg mb-2">Soil Type</h3>
                      <p className="text-2xl font-bold text-primary capitalize">
                        {result.soilType}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Confidence: {result.confidence}%
                      </p>
                    </div>

                    <div>
                      <h3 className="font-bold mb-2">Characteristics</h3>
                      <p className="text-muted-foreground">{result.characteristics}</p>
                    </div>

                    <div>
                      <h3 className="font-bold mb-2">Recommended Crops</h3>
                      <div className="flex flex-wrap gap-2">
                        {result.recommendedCrops.map((crop: string, index: number) => (
                          <span
                            key={index}
                            className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm"
                          >
                            {crop}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                    <Upload className="w-16 h-16 mb-4 opacity-50" />
                    <p>Upload and analyze an image to see results</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SoilDetection;
