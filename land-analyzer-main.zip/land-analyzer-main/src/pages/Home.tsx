import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FlaskConical, Sprout, Activity } from "lucide-react";
import soilHero from "@/assets/soil-hero.jpg";

interface HomeProps {
  isAuthenticated: boolean;
}

const Home = ({ isAuthenticated }: HomeProps) => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      <Navigation isAuthenticated={isAuthenticated} />

      {/* Hero Section */}
      <div
        className="relative h-[500px] bg-cover bg-center flex items-center justify-center"
        style={{ backgroundImage: `url(${soilHero})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40" />
        <div className="relative z-10 text-center text-white max-w-3xl px-4">
          <h1 className="text-5xl font-bold mb-4">
            Soil Fertility Prediction & Detection
          </h1>
          <p className="text-xl mb-8">
            Advanced AI-powered soil analysis for optimal crop production
          </p>
          {!isAuthenticated && (
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              Get Started
            </Button>
          )}
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="p-6 hover:shadow-soil transition-shadow cursor-pointer" onClick={() => navigate("/soil-detection")}>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <FlaskConical className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Soil Detection</h3>
              <p className="text-muted-foreground">
                Upload soil images for instant type identification and crop recommendations
              </p>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-soil transition-shadow cursor-pointer" onClick={() => navigate("/fertility-check")}>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-secondary/10 flex items-center justify-center">
                <Activity className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-xl font-bold">Fertility Analysis</h3>
              <p className="text-muted-foreground">
                Comprehensive soil fertility testing with detailed mineral recommendations
              </p>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-soil transition-shadow">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
                <Sprout className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold">Crop Recommendations</h3>
              <p className="text-muted-foreground">
                Get personalized crop suggestions based on your soil analysis results
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Home;
