import Home from "./Home";

interface IndexProps {
  isAuthenticated: boolean;
}

const Index = ({ isAuthenticated }: IndexProps) => {
  return <Home isAuthenticated={isAuthenticated} />;
};

export default Index;
