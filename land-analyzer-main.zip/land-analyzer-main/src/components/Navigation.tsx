import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Leaf, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface NavigationProps {
  isAuthenticated: boolean;
}

export const Navigation = ({ isAuthenticated }: NavigationProps) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error("Error signing out");
    } else {
      toast.success("Logged out successfully");
      navigate("/auth");
    }
  };

  return (
    <nav className="bg-gradient-earth shadow-soil">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 text-primary-foreground font-bold text-xl">
            <Leaf className="w-6 h-6" />
            <span>Soil Fertility Prediction</span>
          </Link>

          {isAuthenticated && (
            <div className="flex items-center gap-6">
              <Link to="/" className="text-primary-foreground hover:text-accent transition-colors">
                Home
              </Link>
              <Link to="/soil-detection" className="text-primary-foreground hover:text-accent transition-colors">
                Soil Detection
              </Link>
              <Link to="/fertility-check" className="text-primary-foreground hover:text-accent transition-colors">
                Fertility Check
              </Link>
              <Link to="/about" className="text-primary-foreground hover:text-accent transition-colors">
                About
              </Link>
              <Link to="/feedback" className="text-primary-foreground hover:text-accent transition-colors">
                Feedback
              </Link>
              <Button
                variant="secondary"
                size="sm"
                onClick={handleLogout}
                className="gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
