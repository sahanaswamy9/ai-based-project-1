import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import SoilDetection from "./pages/SoilDetection";
import FertilityCheck from "./pages/FertilityCheck";
import About from "./pages/About";
import Feedback from "./pages/Feedback";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) return null;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={session ? <Navigate to="/" /> : <Auth />} />
            <Route path="/" element={session ? <Index isAuthenticated={true} /> : <Navigate to="/auth" />} />
            <Route path="/soil-detection" element={session ? <SoilDetection isAuthenticated={true} /> : <Navigate to="/auth" />} />
            <Route path="/fertility-check" element={session ? <FertilityCheck isAuthenticated={true} /> : <Navigate to="/auth" />} />
            <Route path="/about" element={session ? <About isAuthenticated={true} /> : <Navigate to="/auth" />} />
            <Route path="/feedback" element={session ? <Feedback isAuthenticated={true} /> : <Navigate to="/auth" />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
